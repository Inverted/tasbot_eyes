var searchData=
[
  ['translatecolor_0',['translateColor',['../main_8c.html#a78a0edead44a3266971195088d02723a',1,'main.c']]]
];
