var searchData=
[
  ['getblinkamount_0',['getBlinkAmount',['../main_8c.html#a09bcfdc8fbda3be40df2f6eb0d80ecb2',1,'main.c']]],
  ['getblinkdelay_1',['getBlinkDelay',['../main_8c.html#a2d9407ec1024d8226dbc78b350adab5e',1,'main.c']]],
  ['getdelaytime_2',['getDelayTime',['../main_8c.html#ada3f603d39a4de308a1da96bc40afa7f',1,'main.c']]],
  ['getfilelist_3',['getFileList',['../main_8c.html#aadb77045c58319fc7e02776be6deea74',1,'main.c']]],
  ['getfilepath_4',['getFilePath',['../main_8c.html#a8e004ddb566b050333543770c0919040',1,'main.c']]],
  ['getluminance_5',['getLuminance',['../main_8c.html#af5a101c6b535e4f0bbb687d9ee18590f',1,'main.c']]],
  ['getrandomanimation_6',['getRandomAnimation',['../main_8c.html#ab1dd2e3d1d41fbfef252d9fede57632f',1,'main.c']]]
];
