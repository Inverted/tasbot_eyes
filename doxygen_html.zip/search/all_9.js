var searchData=
[
  ['readanimation_0',['readAnimation',['../main_8c.html#ad59750beb55d81d06366926ae10a6579',1,'main.c']]],
  ['readfile_1',['readFile',['../main_8c.html#aa59a012d54f6ac7cf3f9d15d1183b98d',1,'main.c']]],
  ['readframepixels_2',['readFramePixels',['../main_8c.html#ac452848163f024b64bd80742352c6f6b',1,'main.c']]],
  ['readpalette_3',['readPalette',['../main_8c.html#a43acb37e0dbd7b701c3c721b70af94fc',1,'main.c']]],
  ['renderleds_4',['renderLEDs',['../main_8c.html#aff386bb43bb33ee500d8e9240dd8812a',1,'main.c']]]
];
