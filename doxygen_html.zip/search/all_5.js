var searchData=
[
  ['ledmatrixtranslation_0',['ledMatrixTranslation',['../main_8c.html#a904b807c7ba8bc6dd9863e2a3df87983',1,'main.c']]]
];
